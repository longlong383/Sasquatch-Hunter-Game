package com.example.clickcountertryout;

import androidx.appcompat.app.AppCompatActivity;

import android.icu.text.IDNA;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    TextView wordPop;
    TextView InfoHealth ;
    Button nukeButton;
    Button laserButton;
    Button shootButton;
    Button rpgButton;
    int sasquash;
    int you;
    int gun;
    int rpg;
    int laser;
    int sasquash2;
    boolean firstSasquash;
    Random random;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        wordPop = findViewById(R.id.info);
        InfoHealth = findViewById(R.id.InfoHealth) ;
        nukeButton = findViewById(R.id.nuke);
        laserButton = findViewById(R.id.laser);
        shootButton = findViewById(R.id.shoot) ;
        rpgButton = findViewById(R.id.rPG) ;
        sasquash = 200;
        you = 150;
        gun = 60;
        rpg = 100;
        laser = 150;
        sasquash2 = 151;
        firstSasquash = true;
        random = new Random();
        wordPop.setText("A wild Sasquash has appeared!");
        wordPop.append("\n" + "What would you like to do?") ;
        wordPop.append("\n" + "Heads up, you can only use each button only once") ;
        InfoHealth.setText("Sasquash health: " + sasquash) ;
        InfoHealth.append("\n" + "Your health: " + you) ;
    }

    public void shootingHim(View View) {
        sasquash = sasquash - gun;
        if (sasquash <= 0) {
            wordPop.setText("\n" + "The Sasquash is dead. You live another day");
            shootButton.setEnabled(false);
            InfoHealth.setText("Sasquash health: 0") ;
            InfoHealth.append("\n" + "Your health doesn't matter") ;
            anothermonster();
        } else {
            wordPop.append("\n" + "You attacked the Sasquash with a M2 Browning Machine Gun and shot IT a few thousand times ");
            InfoHealth.setText("Sasquash health: " + sasquash);
            sasquashattack();
            shootButton.setEnabled(false);
        }
    }

    public void rocketinghim(View view) {
        sasquash = sasquash - rpg;
        if (sasquash <= 0) {
            wordPop.setText("\n" + "The Sasquash is dead. You live another day");
            rpgButton.setEnabled(false);
            InfoHealth.setText("Sasquash Health: 0") ;
            InfoHealth.append("\n" + "Your health doesn't matter") ;
            anothermonster();
        } else {
            wordPop.append("\n" + "You attacked the Sasquash with a RPG and a few intercontinental missiles");
            InfoHealth.setText("Sasquash health: " + sasquash);
            sasquashattack();
            rpgButton.setEnabled(false);
        }
    }
    public void laser(View view) {
        int laserDamage = random.nextInt(laser) + 5;
        sasquash = sasquash - laserDamage ;
        if (sasquash <=0) {
            wordPop.setText("\n" +"The Sasquash is dead. You live another day") ;
            laserButton.setEnabled(false);
            InfoHealth.setText("Sasquash Health: 0") ;
            InfoHealth.append("\n" + "Your health doesn't matter") ;
            anothermonster();
        }
        else {
            wordPop.append("\n" + "You attempted to hit the Sasquash with a intergalactic spaceweapon which you stole from Trump ");
            InfoHealth.setText("Sasquash health : " + sasquash);
            sasquashattack();
            laserButton.setEnabled(false);
        }
    }

    public void nuke(View view) {
        wordPop.append("\n" +"You killed everyone on the planet you stupid idiot. What did you think a nuke would do?");
        wordPop.append("\n" + "Man, you either pushed the button because for one this was your last resort, or two, you saw a button that you wanted to press") ;
        wordPop.append("\n" + "Hey, at least you killed the Sasquash - and yourself, stupid") ;
        InfoHealth.setText("Sasquash health: 0") ;
        InfoHealth.append("\n" + "Your health: -200" ) ;
        nukeButton.setEnabled(false);
        laserButton.setEnabled(false);
        shootButton.setEnabled(false);
        rpgButton.setEnabled(false);
    }
    private void sasquashattack() {
        int sasquashattack = random.nextInt(sasquash2) + 5;
        you = you - sasquashattack;
        if (you<= 0) {
            wordPop.append("\n" + "The Sasquash retaliated!") ;
            wordPop.append("\n" + "The Sasquash slapped the poop out of you") ;
            wordPop.append("\n" +"You lost you loser. How could you lose to a Sasquash?") ;
            wordPop.append("\n" + "Sasquash's now rule the world") ;
            InfoHealth.setText("The Sasquash has unlimted health") ;
            InfoHealth.append("\n" + "You have -10000000 health") ;
            nukeButton.setEnabled(false);
            laserButton.setEnabled(false);
            shootButton.setEnabled(false);
            rpgButton.setEnabled(false);
        }
        else {
            wordPop.append("\n" + "The Sasquash retaliated!") ;
            wordPop.append("\n" + "He slapped you across the face. Ouch!") ;
            InfoHealth.append("\n" +"Your health: " + you) ;
            wordPop.append("\n" + "What would you like to do next?") ;
        }

    }
    public void startover(View view) {
        sasquash = 200;
        you = 150;
        gun = 60;
        rpg = 100;
        laser = 150;
        sasquash2 = 151;
        nukeButton.setEnabled(true);
        laserButton.setEnabled(true);
        shootButton.setEnabled(true);
        rpgButton.setEnabled(true);
        wordPop.setText("A wild Sasquash has appeared!");
        wordPop.append("\n" + "What would you like to do?");
        wordPop.append("\n" + "Heads up, you can only use each button only once") ;
        InfoHealth.setText("Sasquash health: " + sasquash) ;
        InfoHealth.append("\n" + "Your health: " + you) ;
    }
    private void anothermonster() {
        if (firstSasquash) {

            sasquash = 200 * 2;
            you = 150 * 2;
            nukeButton.setEnabled(true);
            laserButton.setEnabled(true);
            shootButton.setEnabled(true);
            rpgButton.setEnabled(true);
            wordPop.append("\n" + "Hey, another Sasquash popped up! It's her husband - yeah, didn't know it was a she, didn't you?");
            wordPop.append("\n" + "What would you like to do?");
            InfoHealth.setText("Your health 2nd Round: " + you);
            InfoHealth.append("\n" + "Sasquash health 2nd Round: " + sasquash);
            gun = gun * 2;
            rpg = rpg * 2;
            laser = laser * 2;
            sasquash2 = sasquash2 * 2;
            firstSasquash = false;
        }
        else {
            wordPop.append("You have destroyed the entire family! Congratulations, I guess...");
        }
    }
}

